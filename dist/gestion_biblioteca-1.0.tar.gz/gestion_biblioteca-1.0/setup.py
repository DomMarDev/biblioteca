from setuptools import setup
setup(
    name = 'gestion_biblioteca',
    version = '1.0',
    description = 'Paquete de gestión de biblioteca',
    autor = 'Domingo',
    mail = 'Domingo-Marchan@hotmail.com',
    url = 'http://www.web.com',
    packages = ['modulos'],
    scripts = []
)